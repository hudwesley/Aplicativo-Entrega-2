package ferramentas;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class EventoDB extends SQLiteOpenHelper {

    private Context contexto;

    public EventoDB(Context cont){
        super(cont, "login", null, 1);
        contexto = cont;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Cria a tabela
        final String criaTabela = "CREATE TABLE IF NOT EXISTS login(email TEXT PRIMARY KEY, senha TEXT)";
        db.execSQL(criaTabela);
    }

    public Boolean insereUsuario(String email, String senha){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put("email", email);
        cv.put("senha", senha);
        //inserir os valores na tabela Login
        long result = db.insert("login", null, cv);
        if(result==-1){
            return false;
        } else{
            return true;
        }

    }
    public Boolean validaLogin(String email){
        //Verificar se já existe o email no DB
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM login WHERE email  = ? ", new String[] {email});
        if(cursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }

    public Boolean validaLoginSenha(String email, String senha){
        //Verificar se o email e senha existem para realizar o login
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM login WHERE email = ? and senha = ?", new String[] {email, senha});
        if(cursor.getCount()>0){
            return true;
        }else{
            return false;
        }
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}
